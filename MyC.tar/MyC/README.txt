Une façon de lancer le compilateur:

./runComp ex1.0

pour compiler l'exemples ex1.0.myc.
